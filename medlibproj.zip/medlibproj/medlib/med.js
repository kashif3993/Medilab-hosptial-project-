let mbars = document.querySelector(".btn-bar");
let mblmenu = document.querySelector(".mbl-ul ");
let mlsmenu = document.querySelector(".mbl-drop");
let mblsubm = document.querySelector(".mbl-subm");
let secli = document.querySelector(".msub-main");
let last = document.querySelector(".mbl-lastmenu");
let ibtn = document.querySelector(".ibtn");
// appointmen section
let appform = document.querySelector('.app-inputs');
let apoib = document.getElementById("apoi-btn");
let appinputs = document.querySelectorAll('input')
mbars.addEventListener("click", () => {

    if (mblmenu.style.display === 'none') {
        mblmenu.style.display = "block";
    }
    else {
        mblmenu.style.display = 'none';
    }

})

// Toggle the first submenu under "Departments"
mlsmenu.addEventListener("click", (e) => {
    e.stopPropagation(); // Prevents the click from closing the main menu
    mblsubm.style.display = mblsubm.style.display === 'block' ? 'none' : 'block';

    // Update the button styling
    if (mblsubm.style.display === 'block') {
        ibtn.style.backgroundColor = '#1977cc';
        ibtn.style.color = 'white';
        ibtn.style.transform = 'rotate(180deg)';
    } else {
        ibtn.style.backgroundColor = 'rgba(172, 172, 255, 0.452)';
        ibtn.style.color = 'grey';
        ibtn.style.transform = 'rotate(0deg)';
    }
});

// Toggle the second submenu inside the first submenu
// Toggle the second submenu inside the first submenu
secli.addEventListener("click", (e) => {
    e.stopPropagation(); // Prevents the click from affecting the parent submenu
    last.style.display = last.style.display === 'block' ? 'none' : 'block';

    // Update the button styling for .msub-main
    if (last.style.display === 'block') {
        secli.querySelector('.ibtn').style.backgroundColor = '#1977cc';
        secli.querySelector('.ibtn').style.color = 'white';
        secli.querySelector('.ibtn').style.transform = 'rotate(180deg)';
    } else {
        secli.querySelector('.ibtn').style.backgroundColor = 'rgba(172, 172, 255, 0.452)';
        secli.querySelector('.ibtn').style.color = 'grey';
        secli.querySelector('.ibtn').style.transform = 'rotate(0deg)';
    }
});

const showTab = (tabId) => {
    // Get all tab sections and remove 'active' class
    document.querySelectorAll('.deps-text').forEach(tab => tab.classList.remove('active'));

    // Add 'active' class to the selected tab
    document.getElementById(tabId).classList.add('active');
};

// Array of tab IDs
const tabs = ['cardio', 'neuro', 'hepa', 'pedia', 'eye'];

// Loop through each tab and add an event listener
tabs.forEach(tab => {
    const linkElement = document.getElementById(`${tab}-link`);
    if (linkElement) { // Check if element exists
        linkElement.addEventListener('click', (event) => {
            event.preventDefault();
            showTab(tab);
        });
    }
});



// faqs section 

let faq = document.querySelectorAll('.faqs-b-body');
let faqb = document.querySelectorAll('.scrol-text');
let faqw = document.querySelectorAll('.faqs-text');
let ang = document.querySelectorAll('.itext');
faq.forEach((kas, index) => {
    kas.addEventListener('click', () => {
        if (faqb[index].style.display === 'none') {
            faqb[index].style.display = 'block';
            ang[index].style.transform = 'rotate(90deg)';
            ang[index].style.color = 'white';
            faq[index].style.backgroundColor = '#1977cc';
            // faq[index].style.color='white';
            const wlr = faqw[index].querySelectorAll('span');
            //    wlr.style.color='white';
            wlr.forEach(sam => {
                sam.style.color = "white"
            })
        }
        else {
            faqb[index].style.display = 'none';
            ang[index].style.transform = 'rotate(0deg)';
            faq[index].style.backgroundColor = 'white';
            ang[index].style.color = '#2c4964';
            const wlr = faqw[index].querySelectorAll('span');
            wlr.forEach(sam => {
                sam.style.color = "#2c4964";
            })

        }
    })
})


// testimonial
const slides = document.querySelectorAll('.fr-sliding'); // Select all slides
const dots = document.querySelectorAll('.dot'); // Select all dots for pagination
let currentSlide = 0; // Start with the first slide
const slideInterval = 3000; // Set slide interval (e.g., 3000ms or 3 seconds)

// Function to update the active slide
function showSlide(index) {
    // Assuming `slides` and `dots` are arrays containing the slide elements and dot indicators
    slides.forEach((slide, i) => {
        // Add 'test-active' class only to the current slide, remove it from others
        slide.classList.toggle('test-active', i === index);
        // Add 'test-content' class to all slides except the active one
        slide.classList.toggle('test-content', i !== index);
    });

    // Update dot indicators to highlight the active slide
    dots.forEach((dot, i) => {
        // Set dot color based on whether it's the active slide's dot
        dot.style.backgroundColor = i === index ? '#1977cc' : 'rgba(120, 128, 131, 0.493)';
    });
}


// Function to go to the next slide
function nextSlide() {
    currentSlide = (currentSlide + 1) % slides.length; // Increment slide index and wrap around if needed
    showSlide(currentSlide);
}

// Start the slider
setInterval(nextSlide, slideInterval);

// Add click event listeners for each dot to allow manual slide selection
dots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
        currentSlide = index; // Update current slide index
        showSlide(currentSlide); // Show selected slide
    });
});



// window.addEventListener('scroll', () => {
//     tbr = document.querySelector('.top-navbar');
//     upbtn = document.querySelector('.arrowbtn');
//     if (window.scrollY > 200) {
//         upbtn.style.display = 'block';
//         upbtn.style.right='0';
//     }
//     else {
//         upbtn.style.display = 'none';
//         upbtn.style.right='-100px';
//         upbtn.style.borderRadius='none';
//     }

//     // Scroll smoothly to the top when the button is clicked
//     upbtn.addEventListener("click", () => {
//         window.scrollTo({
//             top: 0,
//             behavior: "smooth"
//         });
//     });
// });
